# BrandGuard AI

Brand impersonation & typosquatting detection dashboard (demo). Detection runs client-side in JavaScript using a Levenshtein-distance heuristic against a generated dataset of ~3,000 original and fake brand names. Flask serves the files.

## Structure

```
brandguard/
├── app.py              # Flask server
├── requirements.txt
├── README.md
├── templates/
│   └── index.html      # Page markup (links CSS and JS via url_for)
└── static/
    ├── style.css       # Custom styles (scrollbar, fonts)
    └── script.js       # Detection engine, database explorer, charts, takedowns
```

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Notes

- Tailwind, Lucide, Chart.js and Google Fonts load from CDNs, so an internet connection is required.
- Brand logos use Google's favicon service.
- Dashboard numbers, takedown data, the ML tuner and "Re-Train" button are demo placeholders, not real model training or real enforcement.
- To go further, move the dataset and `runDetection` logic into a Flask API route (e.g. `/api/analyze`) and call it with `fetch()` from `script.js`.
