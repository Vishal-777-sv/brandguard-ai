"""BrandGuard AI - Flask server.

Serves templates/index.html and the static assets (style.css, script.js).
Run:  python app.py   ->   http://127.0.0.1:5000
"""
from flask import Flask, render_template, jsonify

app = Flask(__name__, static_folder="static", template_folder="templates")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    return jsonify(status="ok", service="BrandGuard AI", version="5.2")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
